<div>
    <p>Dato recibido: {{ $datoRecibido }}</p>
    <div>
        <div class="md:text-3xl text-base grid place-items-center">
            <x-circulo-preguntas nombre="¿Que necesito?"/>
        </div>
        <x-cuadro-pregunta titulo="¿Acceder a registrar?" texto="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce congue sem euismod, pretium nibh vel, blandit orci. Nam at dolor dolor. Phasellus sit amet dignissim ligula, consequat venenatis tellus. Pellentesque blandit velit et ante blandit tempor. Suspendisse ut sollicitudin diam. Phasellus fermentum, ex id blandit placerat, sem nisi commodo augue"/>
        <x-cuadro-pregunta titulo="Procede a contestar formulario" texto="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce congue sem euismod, pretium nibh vel, blandit orci. Nam at dolor dolor. Phasellus sit amet dignissim ligula, consequat venenatis tellus. Pellentesque blandit velit et ante blandit tempor. Suspendisse ut sollicitudin diam. Phasellus fermentum, ex id blandit placerat, sem nisi commodo augue"/>
        <x-cuadro-pregunta titulo="Esperar que se valide la información" texto="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce congue sem euismod, pretium nibh vel, blandit orci. Nam at dolor dolor. Phasellus sit amet dignissim ligula, consequat venenatis tellus. Pellentesque blandit velit et ante blandit tempor. Suspendisse ut sollicitudin diam. Phasellus fermentum, ex id blandit placerat, sem nisi commodo augue"/>
        <x-cuadro-pregunta titulo="Una vez que se valide podras iniciar sesión" texto="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce congue sem euismod, pretium nibh vel, blandit orci. Nam at dolor dolor. Phasellus sit amet dignissim ligula, consequat venenatis tellus. Pellentesque blandit velit et ante blandit tempor. Suspendisse ut sollicitudin diam. Phasellus fermentum, ex id blandit placerat, sem nisi commodo augue"/>
        
    </div>

    
    
    
</div>
