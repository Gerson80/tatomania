<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Tatomania')); ?></title>

        <!-- Fonts -->
        <link rel="icon" href="<?php echo e(asset('img/icono.png')); ?>" type="image/x-icon">
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

        <!-- Styles -->
        <?php echo \Livewire\Livewire::styles(); ?>

    </head>
    <body class="font-sans antialiased">
            <!-- Page Heading -->
            
            <header >
                 <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('header')->html();
} elseif ($_instance->childHasBeenRendered('5ujCavq')) {
    $componentId = $_instance->getRenderedChildComponentId('5ujCavq');
    $componentTag = $_instance->getRenderedChildComponentTagName('5ujCavq');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('5ujCavq');
} else {
    $response = \Livewire\Livewire::mount('header');
    $html = $response->html();
    $_instance->logRenderedChild('5ujCavq', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    
            </header>
            

            <!-- Page Content -->
            <main >
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('inicio-login')->html();
} elseif ($_instance->childHasBeenRendered('EU6jtpu')) {
    $componentId = $_instance->getRenderedChildComponentId('EU6jtpu');
    $componentTag = $_instance->getRenderedChildComponentTagName('EU6jtpu');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('EU6jtpu');
} else {
    $response = \Livewire\Livewire::mount('inicio-login');
    $html = $response->html();
    $_instance->logRenderedChild('EU6jtpu', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
               
            </main>

            <footer>
                <?php if (isset($component)) { $__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa = $component; } ?>
<?php $component = App\View\Components\Footer::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Footer::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa)): ?>
<?php $component = $__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa; ?>
<?php unset($__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa); ?>
<?php endif; ?>
            </footer>
               
        

        <?php echo $__env->yieldPushContent('modals'); ?>

        <?php echo \Livewire\Livewire::scripts(); ?>

    </body>
</html><?php /**PATH C:\Users\Gerson Herrera\Desktop\tatomania\resources\views/iniciologin.blade.php ENDPATH**/ ?>