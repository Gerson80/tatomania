<div>
    <?php if(!$chat): ?>
    <div>
            <?php if(!$modalDatosPublicacion): ?>
            
            <?php if(!$modalAgregar): ?>
            <div class="flex justify-center items-center mt-7">
                <div class="text-center text-xl w-2/3 text-gray-700">
                    <p>Los tatuajes después de la mastectomía pueden ser una forma significativa de encontrar belleza y empoderamiento después de una experiencia difícil</p>
                </div>
            </div>
        
            <?php if (isset($component)) { $__componentOriginal0556baf2003cf5ae48a2c6312c1e7a56 = $component; } ?>
<?php $component = App\View\Components\IconoMensaje::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icono-mensaje'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\IconoMensaje::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0556baf2003cf5ae48a2c6312c1e7a56)): ?>
<?php $component = $__componentOriginal0556baf2003cf5ae48a2c6312c1e7a56; ?>
<?php unset($__componentOriginal0556baf2003cf5ae48a2c6312c1e7a56); ?>
<?php endif; ?>

            <div class="flex justify-center items-center mt-2">
                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['wire:click' => 'agregarNuevo','class' => 'my-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'agregarNuevo','class' => 'my-4']); ?>
                        Crear
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                </div>
                <div class="flex justify-center items-center my-4 text-gray-600 hover:text-black">
                    <button  wire:click="$set('selectedCategory', '')" class="mx-5">
                        <p class="btn <?php echo e($selectedCategory == '' ? ' text-Adicional' : 'transition duration-300 ease-in-out transform hover:-translate-y-1 hover:scale-110'); ?>"> Varios</p>
                    </button>
                    <button  wire:click="$set('selectedCategory', 'flores')" class="mx-5">
                        <p class="btn <?php echo e($selectedCategory == 'flores' ? ' text-Adicional' : 'transition duration-300 ease-in-out transform hover:-translate-y-1 hover:scale-110'); ?>"> Flores</p>
                    </button>
                    <button  wire:click="$set('selectedCategory', 'animales')" class="mx-5">
                        <p class="btn <?php echo e($selectedCategory == 'animales' ? ' text-Adicional' : 'transition duration-300 ease-in-out transform hover:-translate-y-1 hover:scale-110'); ?>"> Animales</p>
                    </button>
                </div>


                <div>        
                    <?php if($modalVisible): ?>
                        <div class=" fixed inset-0 flex items-center justify-center z-50 text-gray-800">
                            <div class="absolute inset-0 bg-black opacity-50"></div>
                        

                            
                            <div class=" bg-white rounded-xl  relative z-10 w-128">
                                <div class="grid grid-cols-6 bg-Primario rounded-t-lg ">
                                    <div class="col-span-2 border-4 border-transparent border-r-white">
                                        <div class="py-4 px-6">
                                            <img src="<?php echo e(asset('/img/imgi.svg')); ?>" width="200px"  alt="Descripción de la imagen" usemap="#mi-mapa" >
                                        </div>
                                    </div>
                                    <div class="grid grid-rows-2 col-span-4">
                                        <div class="px-16 pt-16">
                                            <div class="text-center text-5xl border-4 border-transparent border-b-white">
                                            <p> OH AHÍ </p>
                                            <p>¡ESTAS!</p>
                                            </div>
                                        </div>
                                        <div>
                                            <div class="mx-16 mt-9 text-xl text-center">
                                                <p >“Su lucha nos inspira a nunca rendirnos y a siempre seguir adelante en cada adversidad”</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Contenido de la ventana modal -->
                                <h2 class="text-2xl font-bold text-center mt-5">CUENTAME TU HISTORIA</h2>
                                <div class="grid place-items-center my-5">
                                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['wire:click' => 'toggleModal','class' => '']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'toggleModal','class' => '']); ?>
                                        Aceptar
                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                </div>
                                
                            </div>
                        </div>
                    <?php endif; ?>
                </div>


                
                <div class="grid grid-cols-12">
                    <div class="col-start-2 col-span-10">

                        <div class="grid grid-cols-3 gap-10 ">
                            <?php $__currentLoopData = $publicaciones->reverse(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $publicacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($publicacion->autorizado=="si"): ?>
                                <?php if($selectedCategory ===  strtolower( $publicacion->categoria)): ?>

                                <div class="h-96 container my-2 block rounded-lg bg-white shadow-[0_2px_15px_-3px_rgba(0,0,0,0.07),0_10px_20px_-2px_rgba(0,0,0,0.04)]">
                                    <div  class="h-56 bg-neutral-200 relative">
                                        <img src="data:image/jpeg;base64,<?php echo e($publicacion->foto); ?>" alt="imagen" class="w-full h-full rounded-t-lg">
                                        <?php if($publicacion->user->id==$user->id): ?>
                                        <button wire:click="opciones(<?php echo e($publicacion->id); ?>)"  class=" m-2 absolute inset-y-0 right-0 transition  duration-300 ease-in-out transform hover:-translate-y-1 hover:scale-110 flex justify-center h-0  sm:h-6  items-center w-10   bg-cover " style="background-image: url('<?php echo e(asset('/img/opciones.svg')); ?>')"></button>
                                        <?php endif; ?>
                                    
                                    </div>
                                    <div class="flex my-3 text-xl uppercase mx-3">
                                        <div class="w-5/6">  <p> <?php echo e($publicacion->user->name); ?> &nbsp <?php echo e($publicacion->user->last_name); ?></p></div>
                                        <div class="w-1/6 relative">  <button wire:click="actualizarContenido2"  class="absolute inset-y-0 right-0 transition  duration-300 ease-in-out transform hover:-translate-y-1 hover:scale-110 flex justify-center h-0  sm:h-10  items-center w-12   bg-cover " style="background-image: url('<?php echo e(asset('/img/mensaje.svg')); ?>')"></button></div>
                                        
                                    </div>
                                    
                                    <div class="flex justify-center items-center">
                                        
                                        <p class="mr-2 inline-flex items-center px-2 py-1 bg-Secundario border border-transparent rounded-md font-semibold text-xs text-white  tracking-widest    ">Tatuador</p>
                                        <p class="ml-2 uppercase"><?php echo e($publicacion->name); ?> &nbsp <?php echo e($publicacion->last_name); ?></p>
                                    </div> 
                                    <div class=" text-l mt-5 mx-3">
                                        <button wire:click="mostrarCPublicacion(<?php echo e($publicacion->id); ?>)" class="bg-Gris rounded-xl px-3 w-full py-2 hover:bg-Primario transition duration-300 ease-in-out transform hover:-translate-y-1 hover:scale-110">La publicación tiene <?php echo e($publicacion->comentariostatus->count()); ?> comentarios </button>
                                        
                                    </div>
                                    
                                </div>
                                <?php endif; ?>
                                <?php if(empty($selectedCategory)): ?>
                                    <div class="h-96 container my-2 block rounded-lg bg-white shadow-[0_2px_15px_-3px_rgba(0,0,0,0.07),0_10px_20px_-2px_rgba(0,0,0,0.04)]">
                                        <div  class="h-56 bg-neutral-200 relative">
                                            <img src="data:image/jpeg;base64,<?php echo e($publicacion->foto); ?>" alt="imagen" class="w-full h-full rounded-t-lg">
                                            <?php if($publicacion->user->id==$user->id): ?>
                                            <button wire:click="opciones(<?php echo e($publicacion->id); ?>)"  class=" m-2 absolute inset-y-0 right-0 transition  duration-300 ease-in-out transform hover:-translate-y-1 hover:scale-110 flex justify-center h-0  sm:h-6  items-center w-10   bg-cover " style="background-image: url('<?php echo e(asset('/img/opciones.svg')); ?>')"></button>
                                            <?php endif; ?>
                                        
                                        </div>
                                        <div class="flex my-3 text-xl uppercase mx-3">
                                            <div class="w-5/6 ">  <p> <?php echo e($publicacion->user->name); ?> &nbsp <?php echo e($publicacion->user->last_name); ?></p></div>
                                            <div class="w-1/6 relative">  <button wire:click="activarChat"  class="absolute inset-y-0 right-0 transition  duration-300 ease-in-out transform hover:-translate-y-1 hover:scale-110 flex justify-center h-0  sm:h-10  items-center w-12   bg-cover " style="background-image: url('<?php echo e(asset('/img/mensaje.svg')); ?>')"></button></div>
                                            
                                        </div>
                                        
                                        <div class="flex justify-center items-center">
                                            
                                            <p class="mr-2 inline-flex items-center px-2 py-1 bg-Secundario border border-transparent rounded-md font-semibold text-xs text-white  tracking-widest    ">Tatuador</p>
                                            <p class="ml-2 uppercase"><?php echo e($publicacion->name); ?> &nbsp <?php echo e($publicacion->last_name); ?></p>
                                        </div> 
                                        <div class=" text-l mt-5 mx-3">
                                            <button wire:click="mostrarCPublicacion(<?php echo e($publicacion->id); ?>)" class="bg-Gris rounded-xl px-3 w-full py-2 hover:bg-Primario transition duration-300 ease-in-out transform hover:-translate-y-1 hover:scale-110">La publicación tiene <?php echo e($publicacion->comentariostatus->count()); ?> comentarios </button>
                                            
                                        </div>
                                        
                                    </div>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            
                            
                        </div>


                    </div>
                    
                    
                
                </div>

                <div>        
                    <?php if($modalOpciones): ?>
                        <div class=" fixed inset-0 flex items-center justify-center z-50 text-gray-800">
                            <div class="absolute inset-0 bg-black opacity-50"></div>
                        

                            
                            <div class=" bg-white rounded-2xl  relative z-10 w-80">
                                <div class="bg-Primario m-1 rounded-xl h-8">
                                <p class="ml-3 pt-1">Hola <?php echo e($user->name); ?></p>
                                    <button  wire:click="opciones2"> <img src="<?php echo e(asset('/img/x.svg')); ?>" width="15" height="15" alt="Descripción de la imagen" usemap="#mi-mapa" class="my-3 transition duration-300 ease-in-out transform hover:-translate-y-1 hover:scale-110 absolute inset-y-0 right-0 m-2"></button>

                                </div>
                                <div class="grid text-3xl place-items-center mt-6">
                                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['wire:click' => 'editarPublicacion']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'editarPublicacion']); ?>
                                        Editar 
                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                </div>
                                <div class="grid text-3xl place-items-center my-6">
                                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['wire:click' => 'deleteCard']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'deleteCard']); ?>
                                        Eliminar
                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                </div>
                                
                                
                                
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                <?php endif; ?>


                <?php if($modalAgregar): ?>
                <div class="m-10 border-2 border-Adicional">
                    <div class="text-center text-2xl mt-3">
                        <h1>Foto</h1>
                    </div>
                    <div class="grid place-items-center">
                        <div class="flex items-center border-2 border-Primario">
                            <label for="imagen" class="cursor-pointer">
                                
                                <input type="file" id="imagen" wire:model="imagen" class="hidden" style="background-image: url('<?php echo e(asset('/img/subir.svg')); ?>')">
                                <div class="w-48 h-48  bg-transparent flex items-center justify-center">
                                    <?php if(!$cualVentanaEntro): ?>
                                        <?php if($imagen): ?>
                                        
                                            <img src="<?php echo e($imagen->temporaryUrl()); ?>" alt="Imagen seleccionada" class="w-48 h-48 ">
                                        <?php else: ?>
                                            <img src="<?php echo e(asset('/img/subir.svg')); ?>" alt="">
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <?php if($imagen): ?>
                                            <img src="<?php echo e($imagen->temporaryUrl()); ?>" alt="Imagen seleccionada" class="w-48 h-48 ">
                                            
                                        <?php elseif($imagen2): ?>
                                            <img src="data:image/jpeg;base64,<?php echo e($imagen2); ?>" alt="">

                                        <?php else: ?>
                                            <img src="<?php echo e(asset('/img/subir.svg')); ?>" alt="">
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    
                                </div>
                                
                                
                            </label>
                            
                        </div>
                        <?php $__errorArgs = ['imagen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-Adicional text-center mt-1"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <?php $__errorArgs = ['imagen2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-Adicional text-center mt-1"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>
                    <div class="grid place-items-center my-3 text-lg">
                        <div class="w-80 flex">
                            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => ' text-lg mt-3 mr-3','for' => 'name','value' => ''.e(__('Categoria')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => ' text-lg mt-3 mr-3','for' => 'name','value' => ''.e(__('Categoria')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                            <select id="categoria" wire:model="categoria" name="categoria" :value="old('categoria')"  class=" bg-transparent border border-Primario text-gray-900 text-sm rounded-lg focus:ring-Secundario focus:border-Secundario block w-full p-2.5 ">
                                <option selected>Elige una opción</option>
                                <option value="flores"  class="bg-transparent hover:bg-Secundario focus:ring-Secundario">Flores</option>
                                <option value="animales">Animales</option>
                                <option value="varios">Varios</option>
                            
                            </select>

                        </div>
                        <?php $__errorArgs = ['categoria'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-Adicional text-center mt-1"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                
                    </div>
                    <div class="grid grid-cols-6 gap-4 mx-5 text-lg border-2 border-transparent border-b-Primario">
                        <div class="col-start-2 col-span-4">
                            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => ' text-lg mt-3','for' => 'name','value' => ''.e(__('Historia')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => ' text-lg mt-3','for' => 'name','value' => ''.e(__('Historia')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                            <div class="w-full">
                                <div class="px-4">
                                    <p class="text-gray-500 text-sm">Cuéntanos la historia que tienes acerca de este tatuaje.</p>
                                </div>
                                <textarea placeholder="Este tatuaje me lo hice..." id="historia" wire:model="historia" name="historia" : cols="30" rows="3" class=" mb-3 w-full block border-b-black autofill:bg-white border-2 border-transparent bg-white focus:border-Secundario focus:bg-white focus:outline-none"></textarea>
                            </div>
                            
                            <?php $__errorArgs = ['historia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-Adicional text-center mt-1"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                       
                    </div>
                    <h2 class="text-center text-lg mt-4 ">Datos del tatuador</h2>
                    <div class="grid grid-cols-6 gap-4 mx-5 text-xl">
                        <div class="col-start-2 col-span-4">
                            <div class="mt-2">
                                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => ' text-lg mt-3','for' => 'name','value' => ''.e(__('Nombre')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => ' text-lg mt-3','for' => 'name','value' => ''.e(__('Nombre')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                <div class="w-full">
                                    <div class="px-4">
                                        <p class="text-gray-500 text-sm">Ingresa el nombre o apodo del tatuador.</p>
                                    </div>
                                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input','data' => ['placeholder' => 'Brayan','id' => 'nombre','wire:model' => 'nombre','class' => 'block text-lg mt-1 w-full h-10','name' => 'nombre','value' => old('nombre'),'required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['placeholder' => 'Brayan','id' => 'nombre','wire:model' => 'nombre','class' => 'block text-lg mt-1 w-full h-10','name' => 'nombre','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('nombre')),'required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                </div>
                                
                                <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-Adicional text-center mt-1"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                               
                              

                            </div>
                            <div class="mt-2">
                                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => ' text-lg mt-3','for' => 'name','value' => ''.e(__('Apellidos')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => ' text-lg mt-3','for' => 'name','value' => ''.e(__('Apellidos')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input','data' => ['placeholder' => 'Chan','id' => 'apellidos','wire:model' => 'apellidos','class' => 'block text-lg mt-1 w-full h-10','name' => 'apellidos','value' => old('apellidos'),'required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['placeholder' => 'Chan','id' => 'apellidos','wire:model' => 'apellidos','class' => 'block text-lg mt-1 w-full h-10','name' => 'apellidos','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('apellidos')),'required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                            </div>
                            <div class="mt-2">
                                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => ' text-lg mt-3','for' => 'name','value' => ''.e(__('Cuentame')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => ' text-lg mt-3','for' => 'name','value' => ''.e(__('Cuentame')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                <div class="w-full">
                                    <div class="px-4">
                                        <p class="text-gray-500 text-sm">Cuéntanos la experiencia que tuviste a la hora de hacerte el tatuaje.</p>
                                    </div>
                                    <textarea placeholder="Me atendió muy..." id="cuentame" wire:model="cuentame" name="cuentame" : cols="30" rows="3" class="mt-1 text-lg mb-3 w-full block border-b-black autofill:bg-white border-2 border-transparent bg-white focus:border-Secundario focus:bg-white focus:outline-none"></textarea>
                            
                                </div>
                                
                                <?php $__errorArgs = ['cuentame'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-Adicional text-center mt-1"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                               
                            </div>
                            <div class="mt-2">
                                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => ' text-lg mt-3','for' => 'name','value' => ''.e(__('Numero')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => ' text-lg mt-3','for' => 'name','value' => ''.e(__('Numero')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                <div class="w-full">
                                    <div class="px-4">
                                        <p class="text-gray-500 text-sm">Ingresa el número del tatuador para que más mujeres se puedan comunicar con él.</p>
                                    </div>
                                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input','data' => ['placeholder' => '9911567889','type' => 'number','id' => 'numero','wire:model' => 'numero','class' => 'block text-lg mt-1 w-full h-10','name' => 'numero','value' => old('numero')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['placeholder' => '9911567889','type' => 'number','id' => 'numero','wire:model' => 'numero','class' => 'block text-lg mt-1 w-full h-10','name' => 'numero','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('numero'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                            
                                </div>
                                
                                <?php $__errorArgs = ['numero'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-Adicional text-center mt-1"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                
                            </div>
                            <div class="mt-2">
                                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => ' text-lg mt-3','for' => 'name','value' => ''.e(__('Correo')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => ' text-lg mt-3','for' => 'name','value' => ''.e(__('Correo')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                <div class="w-full">
                                    <div class="px-4">
                                        <p class="text-gray-500 text-sm">Ingresa el correro del tatuador para que más mujeres se puedan comunicar con él.</p>
                                    </div>
                                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input','data' => ['placeholder' => 'Brayan56@itsmotul.com','id' => 'correo','wire:model' => 'correo','class' => 'block text-lg mt-1 w-full h-10','name' => 'correo','value' => old('correo')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['placeholder' => 'Brayan56@itsmotul.com','id' => 'correo','wire:model' => 'correo','class' => 'block text-lg mt-1 w-full h-10','name' => 'correo','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('correo'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                            
                                </div>
                                
                                <?php $__errorArgs = ['correo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-Adicional text-center mt-1"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                
                            </div>
                            <?php if(!$cualVentanaEntro): ?>
                            <div class="grid text-3xl place-items-center my-6">
                                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['wire:click' => 'enviarDatos']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'enviarDatos']); ?>
                                    Guardar
                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                            </div>
                            <?php endif; ?>
                            <?php if($cualVentanaEntro): ?>
                            <div class="grid text-3xl place-items-center my-6">
                                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['wire:click' => 'actualizarDatos']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'actualizarDatos']); ?>
                                    Guardar
                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                            </div>
                            <?php endif; ?>
                        
                        </div>

                    </div>
                    
                    
                    

                </div>
            <?php endif; ?>
        <?php endif; ?>



        
        
        <?php if($modalDatosPublicacion): ?>
        <div>
            <?php if (isset($component)) { $__componentOriginal0556baf2003cf5ae48a2c6312c1e7a56 = $component; } ?>
<?php $component = App\View\Components\IconoMensaje::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icono-mensaje'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\IconoMensaje::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0556baf2003cf5ae48a2c6312c1e7a56)): ?>
<?php $component = $__componentOriginal0556baf2003cf5ae48a2c6312c1e7a56; ?>
<?php unset($__componentOriginal0556baf2003cf5ae48a2c6312c1e7a56); ?>
<?php endif; ?>
            <div class="flex py-5">
                <div class="w-1/12">
            
                </div>
                <div class="w-10/12  flex bg-Primario text-white shadow-[0_2px_15px_-3px_rgba(0,0,0,0.07),0_10px_20px_-2px_rgba(0,0,0,0.04)]">
                    <div class="w-1/6  flex justify-center items-center">
                        <img src="<?php echo e(asset('/img/tatuador3.svg')); ?>" width="130"  alt="Descripción de la imagen" usemap="#mi-mapa" class="rounded-full my-5 ml-3">
                    </div>
                    <div class="w-1/6 grid place-items-center">
                        <div class="text-center uppercase">
                            <p class=" font-semibold text-lg">Tatuador</p>
                            <p class=" text-lg pt-2"><?php echo e($nombre); ?></p>
                            <p class=" text-lg " ><?php echo e($apellidos); ?></p>

                        </div>
                    
                    </div>
                    <div class="w-4/6 mr-3">
                        <p class=" font-semibold pt-4 text-base capitalize">Experiencia de <?php echo e($nombrePublico); ?></p>
                        <p class="pt-1 text-base capitalize"><?php echo e($cuentame); ?></p>
                        <p class="  font-semibold pt-4 text-base ">Contacto</p>
                        <p class="pt-1 text-base ">Numero: <?php echo e($numero); ?></p>
                        <p class="pt-1 pb-4 text-base ">Correro: <?php echo e($correo); ?></p>
                    </div>
                    
                </div>
            </div>

            <div class="flex py-5">
                    <div class="w-1/6">
                
                    </div>
                    <div class="w-4/6  border-solid border-2 border-Secundario">
                        <div class="flex justify-center items-center mt-4">
                            <img src="data:image/jpeg;base64,<?php echo e($imagen2); ?>" alt="imagen">
                        
                        </div>
                        <div class="grid grid-cols-12 gap-4">
                            <div class="col-start-2 col-span-10 text-gray-700 text-justify">
                                <p class=" text-lg p-2 capitalize "><?php echo e($historia); ?></p>
                            </div>
                        
                        </div>
                        
                        
                    </div>
            </div>
        
            <div class="flex py-5">
                <div class="w-1/6">
            
                </div>
                <div class="w-4/6  border-solid border-2 border-Primario">
                    <div class="flex justify-center items-center m-4 text-gray-700">
                        <div class="w-full">
                            <div class="px-4">
                                <p class="text-gray-500 text-sm">Cuéntanos que te parece esta publicación.</p>
                            </div>
                            <textarea wire:model="comentario"  name="comentario"  id="comentario" cols="30" rows="3" class="  w-full border-b-black autofill:bg-white border-2 border-transparent bg-white focus:border-Secundario focus:bg-white focus:outline-none"></textarea>
                        </div>
                    </div>
                    <?php $__errorArgs = ['comentario'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-Adicional text-center mt-1 px-4"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <div class="grid place-items-center mb-4">
                        <?php if(!$cualVentanaEntro2): ?>
                            <div class="grid text-3xl place-items-center my-6">
                                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['type' => 'submit','wire:click' => 'cometarPublicacion','class' => '']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit','wire:click' => 'cometarPublicacion','class' => '']); ?>
                                    Comentar
                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>        
                            </div>
                            <?php endif; ?>
                            <?php if($cualVentanaEntro2): ?>
                            <div class="grid text-3xl place-items-center my-6">
                                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['wire:click' => 'actualizarComentario']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'actualizarComentario']); ?>
                                    Guardar
                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                            </div>
                            <?php endif; ?>
                        
                        
                    </div>
        
                    
                    
                </div>
        </div>
        
        <?php if(!$cualVentanaEntro2): ?>
            <div>
                <?php $__currentLoopData = $comentarios->reverse(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comentario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <?php if($comentario->publicacionestatu_id == $selectedCardId): ?>
                        <div class="flex py-5">
                            <div class="w-1/12">
                            </div>
                            <div class="w-10/12 relative flex bg-transparent text-white border-solid border-2 border-Adicional">
                                <?php if($comentario->user->id==$user->id): ?>
                                <button wire:click="opcionesComentario(<?php echo e($comentario->id); ?>)"  class=" m-2 absolute inset-y-0 right-0 transition  duration-300 ease-in-out transform hover:-translate-y-1 hover:scale-110 flex justify-center h-0  sm:h-6  items-center w-10   bg-cover " style="background-image: url('<?php echo e(asset('/img/opciones.svg')); ?>')"></button>
                                <?php endif; ?>
                                <div class="w-1/6  flex justify-center items-center">
                                    <img src="data:image/jpeg;base64,<?php echo e($comentario->user->foto); ?>" width="130" alt="Descripción de la imagen" class="rounded-full my-5 ml-3">
                                    
                                </div>
                                <div class="w-5/6 text-gray-700">
                                    <p class="mt-6 ml-6 text-xl font-semibold uppercase"><?php echo e($comentario->user->name); ?> <?php echo e($comentario->user->last_name); ?></p>
                                    <div class="ml-4 text-justify">
                                        
                                        <p class=" text-lg p-2 mr-6 mb-2"><?php echo e($comentario->comentario); ?></p>
                                    
                                    </div>
                                    <div class="grid place-items-center mr-9">
                                        <div class="mb-4 pr-9">
                                            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['type' => 'submit','class' => 'mx-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit','class' => 'mx-2']); ?>
                                                <img src="<?php echo e(asset('/img/like.svg')); ?>" width="15" alt="Descripción de la imagen" usemap="#mi-mapa" class="">
                                                <?php $__currentLoopData = $meGusta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $me): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($comentario->id == $me->comentariostatu_id): ?>
                                                <?php echo e($me->valor); ?>

                                                <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['type' => 'submit','class' => 'mx-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit','class' => 'mx-2']); ?>
                                                enviar mensaje
                                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

                                        </div>
                                    </div>


                                
                                </div>
                                
                            </div>
                        </div>
                    <?php endif; ?>
                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>
            <?php if($modalOpcionesComentario): ?>
                        <div class=" fixed inset-0 flex items-center justify-center z-50 text-gray-800">
                            <div class="absolute inset-0 bg-black opacity-50"></div>
                        

                            
                            <div class=" bg-white rounded-2xl  relative z-10 w-80">
                                <div class="bg-Primario m-1 rounded-xl h-8">
                                <p class="ml-3 pt-1">Hola <?php echo e($user->name); ?></p>
                                    <button  wire:click="opcionesComentario2"> <img src="<?php echo e(asset('/img/x.svg')); ?>" width="15" height="15" alt="Descripción de la imagen" usemap="#mi-mapa" class="my-3 transition duration-300 ease-in-out transform hover:-translate-y-1 hover:scale-110 absolute inset-y-0 right-0 m-2"></button>

                                </div>
                                <div class="grid text-3xl place-items-center mt-6">
                                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['wire:click' => 'editarComentario']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'editarComentario']); ?>
                                        Editar 
                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                </div>
                                <div class="grid text-3xl place-items-center my-6">
                                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['wire:click' => 'deleteCard2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'deleteCard2']); ?>
                                        Eliminar
                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                </div>
                                
                                
                                
                            </div>
                        </div>
                <?php endif; ?>
            



        </div>
        <?php endif; ?>





    </div>
    <?php endif; ?>
    <?php if($chat): ?>
    <div>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('chat.main')->html();
} elseif ($_instance->childHasBeenRendered('l2696614316-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l2696614316-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l2696614316-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l2696614316-0');
} else {
    $response = \Livewire\Livewire::mount('chat.main');
    $html = $response->html();
    $_instance->logRenderedChild('l2696614316-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
    <?php endif; ?>
</div>

<script>
    document.addEventListener('livewire:load', function () {
    Livewire.on('mensajeEliminar', function (id) {
        Swal.fire({
            title: '¿Segura que lo deseas eliminar?',
            iconHtml: '<img src="<?php echo e(asset('img/delete.svg')); ?>" class="custom-icon">',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Eliminar',
            buttonsStyling: false,
            customClass:{
                icon: 'custom-icon',
                confirmButton: 'mr-5 inline-flex items-center px-4 py-2 bg-Primario border border-transparent rounded-md font-semibold text-xs text-white transition duration-300 ease-in-out transform hover:-translate-y-1 hover:scale-110 uppercase tracking-widest hover:bg-Secundario focus:Secundario active:bg-Secundario focus:outline-none focus:Adicional focus:bg-Secundario focus:ring-offset-2 transition ease-in-out duration-150',
                cancelButton: 'ml-5 inline-flex items-center px-4 py-2 bg-Primario border border-transparent rounded-md font-semibold text-xs text-white transition duration-300 ease-in-out transform hover:-translate-y-1 hover:scale-110 uppercase tracking-widest hover:bg-Secundario focus:Secundario active:bg-Secundario focus:outline-none focus:Adicional focus:bg-Secundario focus:ring-offset-2 transition ease-in-out duration-150'
            },
            }).then((result) => {
            if (result.isConfirmed) {
                Livewire.emit('eliminarArchivo',id);
                Swal.fire({
                    
                    icon: 'success',
                    title: 'Se ha eliminado correctamente',
                    showConfirmButton: false,
                    timer: 1500
                })
                
            }
            });
    });
    Livewire.on('refreshComponent', function () {
        location.reload();
    });
    Livewire.on('mensajeEnviado', function () {
        Swal.fire({
            title: 'Enviado',
            text: 'Su publicación se va a evaluar, le avisamos cuando se autorize',
            iconHtml: '<img src="<?php echo e(asset('img/icono-error.svg')); ?>" class="custom-icon">',
            confirmButtonText: 'Aceptar',
            buttonsStyling: false,
            customClass:{
                icon: 'custom-icon',
                confirmButton: 'inline-flex items-center px-4 py-2 bg-Primario border border-transparent rounded-md font-semibold text-xs text-white transition duration-300 ease-in-out transform hover:-translate-y-1 hover:scale-110 uppercase tracking-widest hover:bg-Secundario focus:Secundario active:bg-Secundario focus:outline-none focus:Adicional focus:bg-Secundario focus:ring-offset-2 transition ease-in-out duration-150'
            },
            }).then((result) => {
            if (result.isConfirmed) {
                location.reload();
                
                
            }
            });
            
    });
    Livewire.on('actializacionLista', function () {
        Swal.fire({
            title: 'Perfecto',
            text: 'Haz actualizado tu publicación correctamente',
            icon: 'success',
            confirmButtonText: 'Aceptar',
            buttonsStyling: false,
            customClass:{
                icon: 'custom-icon',
                confirmButton: 'inline-flex items-center px-4 py-2 bg-Primario border border-transparent rounded-md font-semibold text-xs text-white transition duration-300 ease-in-out transform hover:-translate-y-1 hover:scale-110 uppercase tracking-widest hover:bg-Secundario focus:Secundario active:bg-Secundario focus:outline-none focus:Adicional focus:bg-Secundario focus:ring-offset-2 transition ease-in-out duration-150'
            },
            }).then((result) => {
            if (result.isConfirmed) {
                location.reload();
                
                
            }
            });
            
    });
    Livewire.on('comentarioAgregado', function () {
        Swal.fire({
            title: 'Perfecto',
            text: 'Haz comentado esta publicación correctamente',
            icon: 'success',
            confirmButtonText: 'Aceptar',
            buttonsStyling: false,
            customClass:{
                icon: 'custom-icon',
                confirmButton: 'inline-flex items-center px-4 py-2 bg-Primario border border-transparent rounded-md font-semibold text-xs text-white transition duration-300 ease-in-out transform hover:-translate-y-1 hover:scale-110 uppercase tracking-widest hover:bg-Secundario focus:Secundario active:bg-Secundario focus:outline-none focus:Adicional focus:bg-Secundario focus:ring-offset-2 transition ease-in-out duration-150'
            },
            }).then((result) => {
            if (result.isConfirmed) {
                
                location.reload();
                
                
            }
            });
            
    });
    Livewire.on('actualComentario', function () {
        Swal.fire({
            title: 'Perfecto',
            text: 'Haz actualizado tu comentario correctamente',
            icon: 'success',
            confirmButtonText: 'Aceptar',
            buttonsStyling: false,
            customClass:{
                icon: 'custom-icon',
                confirmButton: 'inline-flex items-center px-4 py-2 bg-Primario border border-transparent rounded-md font-semibold text-xs text-white transition duration-300 ease-in-out transform hover:-translate-y-1 hover:scale-110 uppercase tracking-widest hover:bg-Secundario focus:Secundario active:bg-Secundario focus:outline-none focus:Adicional focus:bg-Secundario focus:ring-offset-2 transition ease-in-out duration-150'
            },
            }).then((result) => {
            if (result.isConfirmed) {
                
                location.reload();
                
                
            }
            });
            
    });
    Livewire.on('mensajeEliminar2', function (id) {
        Swal.fire({
            title: '¿Segura que lo deseas eliminar?',
            iconHtml: '<img src="<?php echo e(asset('img/delete.svg')); ?>" class="custom-icon">',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Eliminar',
            buttonsStyling: false,
            customClass:{
                icon: 'custom-icon',
                confirmButton: 'mr-5 inline-flex items-center px-4 py-2 bg-Primario border border-transparent rounded-md font-semibold text-xs text-white transition duration-300 ease-in-out transform hover:-translate-y-1 hover:scale-110 uppercase tracking-widest hover:bg-Secundario focus:Secundario active:bg-Secundario focus:outline-none focus:Adicional focus:bg-Secundario focus:ring-offset-2 transition ease-in-out duration-150',
                cancelButton: 'ml-5 inline-flex items-center px-4 py-2 bg-Primario border border-transparent rounded-md font-semibold text-xs text-white transition duration-300 ease-in-out transform hover:-translate-y-1 hover:scale-110 uppercase tracking-widest hover:bg-Secundario focus:Secundario active:bg-Secundario focus:outline-none focus:Adicional focus:bg-Secundario focus:ring-offset-2 transition ease-in-out duration-150'
            },
            }).then((result) => {
            if (result.isConfirmed) {
                Livewire.emit('eliminarArchivoo',id);
                Swal.fire({
                    
                    icon: 'success',
                    title: 'Se ha eliminado correctamente',
                    showConfirmButton: false,
                    timer: 1500
                })
                
            }
            });
    });
    Livewire.on('contenidoActualizado', function () {
                window.scrollTo({
                    top: 0,
                    behavior: 'smooth'
                });
    });
    Livewire.on('contenidoActualizado2', function () {
                window.scrollTo({
                    top: 0,
                    behavior: 'auto'
                });
    });
    
});

</script>
<style>
    .custom-icon{
        border: 0;
    }
</style>

<?php /**PATH C:\Users\Gerson Herrera\Desktop\tatomania\resources\views/livewire/inicio-login.blade.php ENDPATH**/ ?>