<div>
    <div class="bg-Primario text-white text-lg">
        <div class="mx-12 py-12 border-2 border-transparent border-b-white">
            <p class="mx-8 font-bold pb-4">ENLACES RAPIDO</p>
            <P class="mx-8 py-1">Sobre nosotros</P>
            <P class="mx-8 py-1">Contáctenos</P>
            <p class="mx-8 py-1">Políticas de privacidad</p>
            <div class="flex ">
                <div class="w-1/2">
                    <p class="mx-8 py-1">Pregunatas frecuentes</p>
                </div>
                <div class="w-1/2 relative ">


               
                    <a href="" class=" ">
                        <img src="<?php echo e(asset('/img/tuiter.png')); ?>" class="transition duration-300 ease-in-out transform hover:-translate-y-1 hover:scale-110 absolute inset-y-0 right-0 m-2"   width="45" height="45" alt="Descripción de la imagen" usemap="#mi-mapa" >
                    </a>
                    <a href="" class=" ">
                        <img src="<?php echo e(asset('/img/ins.png')); ?>"  class="transition duration-300 ease-in-out transform hover:-translate-y-1 hover:scale-110 absolute inset-y-0 right-10 m-2" width="45" height="45"  alt="Descripción de la imagen" usemap="#mi-mapa" >
                    </a>
                    <a href="" class=" ">
                        <img src="<?php echo e(asset('/img/face.png')); ?>" class="transition duration-300 ease-in-out transform hover:-translate-y-1 hover:scale-110 absolute inset-y-0 right-20 m-2" width="45" height="45" alt="Descripción de la imagen" usemap="#mi-mapa" >
                    </a>
            
                      
            
                </div>

            </div>
           
            

            
            
        </div>
        <p class="px-4 py-2">© 2023, TATOMANIA</p>

    </div>
</div><?php /**PATH C:\Users\Gerson Herrera\Desktop\tatomania\resources\views/components/footer.blade.php ENDPATH**/ ?>