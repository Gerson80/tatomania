<div>
    <div class="w-full relative">  <button wire:click="activarChat"  class="fixed inset-y-24 right-5 transition  duration-300 ease-in-out transform hover:-translate-y-1 hover:scale-110 flex justify-center h-0  sm:h-14  items-center w-16   bg-cover " style="background-image: url('{{ asset('/img/IconoChat.svg') }}')"></button></div>
</div>