<?php

namespace App\Filament\Resources\VivenciaResource\Pages;

use App\Filament\Resources\VivenciaResource;
use Filament\Pages\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateVivencia extends CreateRecord
{
    protected static string $resource = VivenciaResource::class;
}
