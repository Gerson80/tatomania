<div>
    <div   class=" flex justify-center h-0  sm:h-60  items-center sm:w-60 m-2 sm:m-8 bg-cover rounded-full" style="background-image: url('{{ asset('/img/circulo.png') }}')">
        <div class="text-center">
            <p class=""> {{ $nombre }}</p>
        </div> 
    </div>
</div>