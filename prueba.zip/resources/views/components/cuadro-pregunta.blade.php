<div>
   <div class="flex py-5">
    <div class="w-1/6">

    </div>
    <div class="w-4/6  flex border-solid border-2 border-Adicional">
        <div class="w-1/6  flex justify-center items-center">
            <img src="{{ asset('/img/elipse.svg') }}" width="112" height="112" alt="Descripción de la imagen" usemap="#mi-mapa" class="">
        </div>
        <div class="w-1/6 flex justify-center items-center">
            <p class=" text-lg p-2">{{ $titulo }}</p>
        </div>
        <div class="w-4/6">
            <p class="pt-4 text-base p-2 text-justify mr-4">{{ $texto }}</p>
        </div>
        
    </div>
   </div>
</div>